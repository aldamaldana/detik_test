<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * 
 */
class Berita extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->helper(array('form','url'));
		$this->load->library(array('table'));
		$this->load->model('berita_model');
	}

	function index()
	{
		$keyword = $this->input->post('pencarian');
		if($keyword != "")
		{
			$where = "judul_berita LIKE '%$keyword%'";
		}
		else
		{
			$where = "";
		}

		$data['sql'] = $this->berita_model->getTable('tbl_berita', "$where", "");

		$this->load->view('berita/index', $data);
	}

	function detail($id_berita)
	{
		$data['sql'] = $this->berita_model->getTable('tbl_berita', "(id_berita='$id_berita')", "");

		$this->load->view('berita/detail', $data);
	}

	function create_new()
	{
		$this->load->library('form_validation');
		$this->_validation();

		$config['upload_path']          = './img/';
    	$config['allowed_types']        = 'gif|jpg|png|jpeg';
    	$this->load->library('upload', $config);

		if ($this->form_validation->run() == FALSE)
		{
			$this->load->view('berita/add_new');
		}
		else
		{
			if ( ! $this->upload->do_upload('gambar'))
		    {
		    	$error = array('error' => $this->upload->display_errors());
		    }
		    else
		    {
		    	$upload_data = $this->upload->data();
		    	$file_name = $upload_data['file_name'];
		    	$nama_file = str_replace(' ', '_', $_FILES['gambar']['name']);

		    	$request = array(
					'judul_berita' 	=> $this->input->post('judul_berita'),
					'deskripsi' 	=> $this->input->post('deskripsi'),
					'penulis' 		=> $this->input->post('penulis'),
					'gambar' 		=> $nama_file,
					'tgl_dibuat' 	=> date('Y-m-d h:i:s')
				);
				$this->berita_model->insert_data('tbl_berita', $request);
		    }

		    $this->session->set_flashdata('message', 'Data berhasil disimpan.');
			redirect('berita');
		}
	}

	function update_berita($id_berita)
	{
		$this->load->library('form_validation');
		$this->_validation();

		$config['upload_path']          = './img/';
    	$config['allowed_types']        = 'gif|jpg|png|jpeg';
    	$this->load->library('upload', $config);

		if ($this->form_validation->run() == FALSE)
		{
			$data['sql'] = $this->berita_model->getTable('tbl_berita', "(id_berita='$id_berita')", "");
			$this->load->view('berita/edit_berita', $data);
		}
		else
		{
			if ( ! $this->upload->do_upload('gambar'))
		    {
		    	//$error = array('error' => $this->upload->display_errors());
		    	$request = array(
					'judul_berita' 	=> $this->input->post('judul_berita'),
					'deskripsi' 	=> $this->input->post('deskripsi'),
					'penulis' 		=> $this->input->post('penulis'),
					'tgl_dibuat' 	=> date('Y-m-d h:i:s')
				);
				$this->berita_model->update_data('tbl_berita', $request, $id_berita);
		    }
		    else
		    {
		    	$upload_data = $this->upload->data();
		    	$file_name = $upload_data['file_name'];
		    	$nama_file = str_replace(' ', '_', $_FILES['gambar']['name']);

		    	$request = array(
					'judul_berita' 	=> $this->input->post('judul_berita'),
					'deskripsi' 	=> $this->input->post('deskripsi'),
					'penulis' 		=> $this->input->post('penulis'),
					'gambar' 		=> $nama_file
				);
				$this->berita_model->update_data('tbl_berita', $request, $id_berita);
		    }

		    $this->session->set_flashdata('message', 'Data berhasil diubah.');
			redirect('berita');
		}
	}

	function delete_data($id_berita)
	{
		$this->berita_model->hapus_data('tbl_berita', $id_berita);

		$this->session->set_flashdata('message', 'Data berhasil dihapus.');
		redirect('berita');
	}

	function upvote_berita($id_berita)
	{
		$sql = $this->berita_model->getVote($id_berita);
		$row = $sql->row();
		$up_vote = $row->up_vote+1;

		$request = array(
			'up_vote' 	=> $up_vote
		);
		$this->berita_model->update_data('tbl_berita', $request, $id_berita);

		$this->session->set_flashdata('message', 'Vote berhasil disimpan.');
		redirect('berita/detail/'.$id_berita);
	}

	function downvote_berita($id_berita)
	{
		$sql = $this->berita_model->getVote($id_berita);
		$row = $sql->row();
		$down_vote = $row->down_vote+1;

		$request = array(
			'down_vote' 	=> $down_vote
		);
		$this->berita_model->update_data('tbl_berita', $request, $id_berita);

		$this->session->set_flashdata('message', 'Vote berhasil disimpan.');
		redirect('berita/detail/'.$id_berita);
	}

	function _validation()
	{
		$this->form_validation->set_rules('judul_berita', 'Judul Berita', 'trim|required');
		$this->form_validation->set_rules('deskripsi', 'Deskripsi', 'trim|required');
		$this->form_validation->set_rules('penulis', 'Penulis', 'trim|required');
		$this->form_validation->set_error_delimiters(' <span style="color:#FF0000">', '</span>');
	}
}