<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Berita</title>
	<style type="text/css">
		.content{
			padding: 20px 30px;
		}
	</style>
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet" />
	<link href="<?php echo base_url(); ?>assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
	<link href="<?php echo base_url(); ?>assets/font_awesome5.3/css/all.min.css" rel="stylesheet" />
</head>
<body>
	<!-- Begin Navbar -->
	<nav class="navbar navbar-dark bg-primary">
	  <a class="navbar-brand" href="<?php echo site_url(); ?>">Detik</a>
	  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
	    <span class="navbar-toggler-icon"></span>
	  </button>
	  <div class="collapse navbar-collapse" id="navbarNavDropdown">
	    <ul class="navbar-nav">
	      <li class="nav-item">
	        <a class="nav-link" href="<?php echo site_url(); ?>berita/create_new">Tambah Berita</a>
	      </li>
	       <li class="nav-item">
	        <a class="nav-link" href="<?php echo site_url(); ?>">Daftar Berita</a>
	      </li>
	    </ul>
	  </div>
	</nav>
	<!-- End Navbar-->

	<!-- Begin Content -->
	<div id="content" class="content">
		<div col class="col-lg-12 m-b-5">
			<?php if ($this->session->flashdata('message')) { ?>
			<div class="alert alert-success fade show">
			  <span class="close" data-dismiss="alert">×</span>
			  <strong>Success!</strong>
			  <?php echo $this->session->flashdata('message'); ?>
			</div>
			<?php }?>
		</div>
		
		<div class="row">
			<div class="col-lg-12" style="margin-bottom: 50px;">
				<h4 class="text-center">
					DAFTAR BERITA
					<small>
					<a data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
						<i>Filter</i>
					</a>
					</small>
				</h4>
			</div>
			<div class="col-lg-12">
				<div class="collapse" id="collapseExample">
				  <div class="card card-body">
				  	<form method="post">
				  		<div class="form-row">
					    	<div class="form-group col-lg-10">
					    		<input type="text" name="pencarian" class="form-control" placeholder="Pencarian berdasarkan judul berita..">
					    	</div>
					    	<div class="form-group col-lg-2">
					    		<button type="submit" class="btn btn-primary">
					    			Cari
					    		</button>
					    	</div>
					    </div>
				  	</form>
				  </div>
				</div>
				<br>
				<br>
			</div>
			<?php
				foreach ($sql->result() as $row) {
			?>
				<div class="col-lg-3">
					<div class="card" style="width: 18rem;">
					  <img src="<?php echo site_url(); ?>img/<?php echo $row->gambar; ?>" class="card-img-top">
					  <div class="card-body">
					    <h5 class="card-title"><?php echo $row->judul_berita; ?></h5>
					    <a href="<?php echo site_url(); ?>berita/detail/<?php echo $row->id_berita ?>" class="btn btn-primary btn-sm">Detail <i class="fa fa-chevron-right"></i></a>
					  </div>
					</div>
				</div>
			<?php
				}
			?>
		</div>
	</div>
	<!-- End Content -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="<?php echo site_url(); ?>assets/bootstrap/js/bootstrap.min.js"></script>
</body>
</html>