<?php defined('BASEPATH') OR exit('No direct script access allowed'); 
	$row = $sql->row();
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Berita</title>
	<style type="text/css">
		.content{
			padding: 20px 30px;
		}
	</style>
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet" />
	<link href="<?php echo base_url(); ?>assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
	<link href="<?php echo base_url(); ?>assets/font_awesome5.3/css/all.min.css" rel="stylesheet" />
</head>
<body>
	<!-- Begin Navbar -->
	<nav class="navbar navbar-dark bg-primary">
	  <a class="navbar-brand" href="<?php echo site_url(); ?>">Detik</a>
	  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
	    <span class="navbar-toggler-icon"></span>
	  </button>
	  <div class="collapse navbar-collapse" id="navbarNavDropdown">
	    <ul class="navbar-nav">
	      <li class="nav-item">
	        <a class="nav-link" href="<?php echo site_url(); ?>berita/create_new">Tambah Berita</a>
	      </li>
	       <li class="nav-item">
	        <a class="nav-link" href="<?php echo site_url(); ?>">Daftar Berita</a>
	      </li>
	    </ul>
	  </div>
	</nav>
	<!-- End Navbar-->

	<!-- Begin Content -->
	<div id="content" class="content">
		<div col class="col-lg-12 m-b-5">
			<?php if ($this->session->flashdata('message')) { ?>
			<div class="alert alert-success fade show">
			  <span class="close" data-dismiss="alert">×</span>
			  <strong>Success!</strong>
			  <?php echo $this->session->flashdata('message'); ?>
			</div>
			<?php }?>
		</div>
		
		<div class="row">

			<div class="col-lg-8">
				<div class="jumbotron">
					<h1 class="display-5"><i class="fa fa-caret-right"></i> <?php echo $row->judul_berita; ?></h1>
					<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
					  <div class="carousel-inner">
					    <div class="carousel-item active">
					      <img src="<?php echo site_url(); ?>img/<?php echo $row->gambar; ?>" class="d-block w-100">
					    </div>
					  </div>
					</div>
					<hr class="my-4">
					<p class="lead"><?php echo $row->deskripsi; ?></p>
				</div>
			</div>

			<div class="col-lg-4">
				<div class="card" style="width: 18rem;">
				  <ul class="list-group list-group-flush">
				    <li class="list-group-item">PENULIS : <?php echo $row->penulis; ?></li>
				    <li class="list-group-item">PUBLIS : <?php echo date('d/M/Y h:i:s', strtotime($row->tgl_dibuat)); ?></li>
				    <li class="list-group-item">
				    	<a href="<?php echo site_url(); ?>berita/update_berita/<?php echo $row->id_berita; ?>" style="color: green;">UPDATE BERITA</a>
				    </li>
				    <li class="list-group-item">
				    	<a href="<?php echo site_url(); ?>berita/delete_data/<?php echo $row->id_berita; ?>" style="color: red;">HAPUS BERITA</a>
				    </li>
				  </ul>
				  <div class="card-body">
				    <a href="<?php echo site_url(); ?>berita/upvote_berita/<?php echo $row->id_berita; ?>" class="card-link"><?php echo $row->up_vote; ?> <i class="fa fa fa-thumbs-up"></i> </a>
				    <a href="<?php echo site_url(); ?>berita/downvote_berita/<?php echo $row->id_berita; ?>" class="card-link"><?php echo $row->down_vote; ?> <i class="fa fa fa-thumbs-down"></i></a>
				  </div>
				</div>
			</div>
		</div>
	</div>
	<!-- End Content -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="<?php echo site_url(); ?>assets/bootstrap/js/bootstrap.min.js"></script>
</body>
</html>