<?php defined('BASEPATH') OR exit('No direct script access allowed'); 
	$row = $sql->row();
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Berita</title>
	<style type="text/css">
		.content{
			padding: 20px 30px;
		}
	</style>
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet" />
	<link href="<?php echo base_url(); ?>assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
	<link href="<?php echo base_url(); ?>assets/font_awesome5.3/css/all.min.css" rel="stylesheet" />
</head>
<body>
	<!-- Begin Navbar -->
	<nav class="navbar navbar-dark bg-primary">
	  <a class="navbar-brand" href="<?php echo site_url(); ?>">Detik</a>
	  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
	    <span class="navbar-toggler-icon"></span>
	  </button>
	  <div class="collapse navbar-collapse" id="navbarNavDropdown">
	    <ul class="navbar-nav">
	      <li class="nav-item">
	        <a class="nav-link" href="<?php echo site_url(); ?>berita/create_new">Tambah Berita</a>
	      </li>
	       <li class="nav-item">
	        <a class="nav-link" href="<?php echo site_url(); ?>">Daftar Berita</a>
	      </li>
	    </ul>
	  </div>
	</nav>
	<!-- End Navbar-->

	<!-- Begin Content -->
	<div id="content" class="content">
		<div class="row">
			<div class="col-lg-12">
				<h4><i class="fa fa-plus"></i> Edit Berita</h4>
				<div class="card">
				  <div class="card-header">
				   <i class="fa fa-file"></i> Form Edit Berita
				  </div>
				  <div class="card-body">
				  	<form method="post" action="" enctype="multipart/form-data">
						<div class="form-group">
							<label for="judul_berita">Judul Berita :</label>
							<input type="text" class="form-control" name="judul_berita" id="judul_berita" value="<?php echo $row->judul_berita ?>">
							<?php echo form_error('judul_berita'); ?>
						</div>
						<div class="form-group">
							<label for="deskripsi">Deskripsi :</label>
							<textarea class="form-control" name="deskripsi"><?php echo $row->deskripsi; ?></textarea>
							<?php echo form_error('deskripsi'); ?>
						</div>
						<div class="form-group">
							<label for="penulis">Penulis :</label>
							<input type="text" name="penulis" id="penulis" class="form-control" value="<?php echo $row->penulis ?>">
							<?php echo form_error('penulis'); ?>
						</div>
						<div class="form-group">
							<label for="gambar">Gambar :</label><br>
							<img src="<?php echo site_url(); ?>img/<?php echo $row->gambar; ?>" width="200">
							<input type="file" name="gambar" id="gambar" class="form-control m-t-5">
							<?php echo form_error('gambar'); ?>
						</div>
						<button type="submit" class="btn btn-primary btn-sm">
							<i class="fa fa-save"></i> Simpan
						</button>
				  	</form>
				  </div>
				</div>
			</div>
		</div>
	</div>
	<!-- End Content -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="<?php echo site_url(); ?>assets/bootstrap/js/bootstrap.min.js"></script>
</body>
</html>