<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * 
 */
class Berita_model extends CI_Model
{
	
	function __construct()
	{
		parent::__construct();
	}

	function getTable($table_name, $filter, $order)
	{
		if($filter){
			$this->db->where($filter);
		}
		if($order){
			$this->db->order_by($order);
		}
		$sql = $this->db->get($table_name);
		return $sql;
	}

	function insert_data($table_name, $data)
	{
		$this->db->insert($table_name, $data);
	}

	function update_data($table_name, $data, $id_berita)
	{
		$this->db->where('id_berita', $id_berita);
		$this->db->update($table_name, $data);
	}

	function hapus_data($table_name, $id_berita)
	{
		$this->db->where('id_berita', $id_berita);
		$this->db->delete($table_name);
	}

	function getVote($id_berita)
	{
		$this->db->select('up_vote, down_vote');
		$this->db->where('id_berita', $id_berita);
		$sql = $this->db->get('tbl_berita');
		return $sql;
	}
}